<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UsersL;
class HomeController extends Controller
{
    public function index() {
        $users= UsersL::get();
       return view("pages.home", compact("users"));

    }

    public function store(Request $req) {
        $user = new UsersL();
        $user->name =  $req->name;
        $user->phone =  $req->phone;
        $user->age =  $req->age;
        $user->save();



         // return redirect()->back()->with('success', 'Comment stored successfully!');  return redirect()->back()->with('success', 'Comment stored successfully!');
           
        }

        

}


